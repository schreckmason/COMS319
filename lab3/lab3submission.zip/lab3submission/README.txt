Both calculators work as expected for many use cases including the EC case:
1. Enter and operand, binary operator, and a second operator followed by equals to display result.
    After equals, either:
        1. type an operator followed by another operand to use the result in a new calculation or
        2. start typing a second operand, operator, operand for a new calculation or
        3. press equals again to preform the same operation on the result (EXTRA-CREDIT).
2. Instead of typing an operand, MR can be used to type the value of what has been stored in to memory (by M+ and M- operations)
3. Clear will get rid of the siplayed operand, and any stored operation.

On the Binary calculator:
4. Pressing unary operators, such as >>, <<, ~ at any time will modify in place the operand displayed.


Overall, they should both work as expected in most, if not all scenarios.