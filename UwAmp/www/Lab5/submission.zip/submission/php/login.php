<html>
   <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
   <script type="text/javascript" src="../js/login.js"></script>
   <head>
      <link rel="stylesheet" href="../css/login.css">
   </head>
   <body>

      <div id="mainDiv">
         <div id="signInDiv">
            <h1>Dope Login Page</h1>
            <div class="left">Name:</div>
            <div class="right"><input id="name" type="text" name="name" value=""/></div>
            <div class="left">Password:</div>
            <div class="right"><input id="password" type="text" name="password" value=""/></div>
            <div class="left">Login:</div>
            <div class="right"><input id="submitLogin" type="button" value="GO!"/></div>
            <div class="right" id="tryAgain"></div>
         </div>

         <table id="posts"></table>

         <div id="createPostDiv"></div>
         <div id="createMsgDiv"></div>
         <div id="inboxDiv"></div>
         
         <table id="messages"></table>
      </div>
   </body>
</html>