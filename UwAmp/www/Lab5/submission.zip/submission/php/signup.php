<html>
   <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
   <script type="text/javascript" src="../js/login.js"></script>
   <head>
      <link rel="stylesheet" href="../css/signup.css">
   </head>
   <body>

      <div id="mainDiv">
         <h1>Super Awesome Signup Page</h1>
         <div id="registerDiv">
         <div class="left">Name:</div>
         <div class="right"><input id="name" type="text" name="name" value=""/></div>
         <div class="left">Desired Password:</div>
         <div class="right"><input id="password" type="text" name="password" value=""/></div>
         <div class="left">Create User:</div>
         <div class="right"><input id="newSignUp" type="button" value="Submit"/></div>
         </div>

         <table id="posts"></table>

         <div id="createPostDiv">

         </div>

      </div>
   </body>
</html>