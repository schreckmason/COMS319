Signup and Login should be self-explanatory
Admin has no password

To create a post, use the 'make a post' button, fill out the fields and press 'Post'.
To edit a post that you created, click on it and edit it in the diologue that appears.

When admin, click on a post to delete it.

Messages appear at the bottom of the same page as posts and can be updated with the inbox button.