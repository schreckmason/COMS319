<?php

sleep(5);
//var_dump($_REQUEST);

echo $_REQUEST["name"];

?>
